import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  Animated,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { toast } from 'sonner-native';

const ContestEntryScreen = () => {
  const [currentPrizePool, setCurrentPrizePool] = useState(2500);
  const [totalEntries, setTotalEntries] = useState(42);
  const [timeLeft, setTimeLeft] = useState('2d 14h');
  const [userPoints, setUserPoints] = useState(150);
  const [userBadges, setUserBadges] = useState(['Early Voter', 'Top Supporter']);
  const [isVoting, setIsVoting] = useState(false);
  
  const handleContestEntry = async () => {
    try {
      // Simulate Stripe payment flow
      toast.loading('Processing payment...');
      await new Promise(resolve => setTimeout(resolve, 1500));
      toast.success('Payment successful! Welcome to the contest!');
      setTotalEntries(prev => prev + 1);
    } catch (error) {
      toast.error('Payment failed. Please try again.');
    }
  };

  const handleVote = async (isFirstVote = false) => {
    try {
      setIsVoting(true);
      if (!isFirstVote) {
        toast.loading('Processing vote payment...');
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      
      // Simulate voting and points
      setUserPoints(prev => prev + (isFirstVote ? 10 : 15));
      toast.success(`Vote recorded! +${isFirstVote ? 10 : 15} points`);
      
      // Check for new badges
      if (userPoints >= 200 && !userBadges.includes('Super Voter')) {
        setUserBadges(prev => [...prev, 'Super Voter']);
        toast.success('🎉 New Badge Unlocked: Super Voter!');
      }
    } catch (error) {
      toast.error('Vote failed. Please try again.');
    } finally {
      setIsVoting(false);
    }
  };

  const renderFeaturedArtist = () => (
    <View style={styles.featuredArtistContainer}>
      <Image
        source={{ uri: 'https://api.a0.dev/assets/image?text=professional%20musician%20performing%20on%20stage%20with%20dramatic%20lighting&aspect=16:9' }}
        style={styles.featuredImage}
      />
      <BlurView intensity={80} style={styles.artistInfoOverlay}>
        <Text style={styles.artistName}>Sarah Mitchell</Text>
        <Text style={styles.artistGenre}>Alternative Rock</Text>
        <View style={styles.voteCount}>
          <MaterialCommunityIcons name="heart" size={16} color="#FF4081" />
          <Text style={styles.voteText}>1,234 votes</Text>
        </View>
        <TouchableOpacity 
          style={styles.voteButton}
          onPress={() => handleVote(true)}
          disabled={isVoting}
        >
          <Text style={styles.voteButtonText}>Vote (First Free!)</Text>
        </TouchableOpacity>
      </BlurView>
    </View>
  );

  const renderUserProfile = () => (
    <View style={styles.userProfileContainer}>
      <LinearGradient  colors={['#2A1668', '#1E133F']}
        style={styles.userProfileGradient}
      >
        <View style={styles.userPoints}>
          <MaterialCommunityIcons name="star" size={24} color="#FFD700" />
          <Text style={styles.pointsText}>{userPoints} Points</Text>
        </View>
        <View style={styles.badgesContainer}>
          {userBadges.map((badge, index) => (
            <View key={index} style={styles.badge}>
              <MaterialCommunityIcons name="shield-star" size={16} color="#FFD700" />
              <Text style={styles.badgeText}>{badge}</Text>
            </View>
          ))}
        </View>
      </LinearGradient>
    </View>
  );

  return (
    <ScrollView style={styles.container}>
      <LinearGradient  colors={['#1E133F', '#2A1668']}
        style={styles.headerGradient}
      >
        <Text style={styles.title}>Artist Prize Pool</Text>
        <View style={styles.prizePoolContainer}>
          <Text style={styles.prizePoolLabel}>Current Prize Pool</Text>
          <Text style={styles.prizePoolAmount}>${currentPrizePool}</Text>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <MaterialCommunityIcons name="account-group" size={24} color="#FFD700" />
              <Text style={styles.statText}>{totalEntries} Entries</Text>
            </View>
            <View style={styles.statItem}>
              <MaterialCommunityIcons name="clock-outline" size={24} color="#FFD700" />
              <Text style={styles.statText}>{timeLeft} Left</Text>
            </View>
          </View>
        </View>
      </LinearGradient>

      {renderUserProfile()}

      <View style={styles.content}>
        <Text style={styles.sectionTitle}>Featured Artist</Text>
        {renderFeaturedArtist()}

        <TouchableOpacity 
          style={styles.enterButton}
          onPress={handleContestEntry}
        >
          <LinearGradient  colors={['#9747FF', '#7C3AED']}
            style={styles.enterButtonGradient}
          >
            <Text style={styles.enterButtonText}>Enter Contest - $25</Text>
          </LinearGradient>
        </TouchableOpacity>

        <View style={styles.infoContainer}>
          <View style={styles.infoItem}>
            <MaterialCommunityIcons name="trophy" size={24} color="#FFD700" />
            <Text style={styles.infoText}>70% of entries go to prize pool</Text>
          </View>
          <View style={styles.infoItem}>
            <MaterialCommunityIcons name="vote" size={24} color="#4CAF50" />
            <Text style={styles.infoText}>First vote is free</Text>
          </View>
          <View style={styles.infoItem}>
            <MaterialCommunityIcons name="currency-usd" size={24} color="#2196F3" />
            <Text style={styles.infoText}>Additional votes $1 each</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,    backgroundColor: '#110B29',
  },
  headerGradient: {
    padding: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 20,
  },
  prizePoolContainer: {
    alignItems: 'center',
    padding: 20,    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 15,
  },
  prizePoolLabel: {
    fontSize: 16,    color: '#FFD700',
    textShadow: '0px 0px 8px rgba(255, 215, 0, 0.5)',
    marginBottom: 8,
  },
  prizePoolAmount: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    color: 'white',
    marginLeft: 8,
    fontSize: 16,
  },
  userProfileContainer: {
    margin: 20,
    marginTop: -20,
    borderRadius: 15,
    overflow: 'hidden',
  },
  userProfileGradient: {
    padding: 15,
    borderRadius: 15,
  },
  userPoints: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  pointsText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  badgesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  badgeText: {
    color: 'white',
    marginLeft: 4,
    fontSize: 12,
  },
  content: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',    color: '#E5E0FF',
    marginBottom: 16,
  },
  featuredArtistContainer: {
    height: 250,
    borderRadius: 15,
    overflow: 'hidden',
    marginBottom: 24,
  },
  featuredImage: {
    width: '100%',
    height: '100%',
  },
  artistInfoOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 15,    backgroundColor: 'rgba(42, 22, 104, 0.85)',
  },
  artistName: {
    fontSize: 18,
    fontWeight: 'bold',    color: '#E5E0FF',
  },
  artistGenre: {
    fontSize: 14,    color: '#B4A5FF',
    marginBottom: 4,
  },
  voteCount: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  voteText: {
    marginLeft: 4,    color: '#B4A5FF',
  },
  voteButton: {    backgroundColor: '#7C3AED',
    padding: 8,
    borderRadius: 20,
    alignItems: 'center',
  },
  voteButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  enterButton: {
    marginBottom: 24,
  },
  enterButtonGradient: {
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  enterButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  infoContainer: {    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 15,
    padding: 20,    shadowColor: '#7C3AED',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoText: {
    marginLeft: 12,
    fontSize: 16,    color: '#E5E0FF',
  },
});

export default ContestEntryScreen;